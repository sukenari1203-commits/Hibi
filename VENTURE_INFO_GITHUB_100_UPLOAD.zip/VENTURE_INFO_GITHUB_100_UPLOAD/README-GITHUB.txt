VENTURE INFO 100社版

GitHub公開:
1. GitHubで新規Repository作成
2. このフォルダ内の index.html / style.css / app.js / .nojekyll をリポジトリ直下へアップロード
3. Settings → Pages
4. Source: Deploy from a branch
5. Branch: main / (root) → Save

index.html がトップページです。
